NULL LUCK MAN v0.8 / Galaxy Z Fold8 Cover Landscape

현재 패키지는 실제 APK가 아니라 Android Studio에서 APK를 빌드하기 위한 프로젝트입니다.
이 환경에는 Android SDK, Gradle, APK 서명 도구가 없고 외부 다운로드가 차단되어 직접 컴파일하지 못했습니다.

빌드 방법 (Android Studio):
1. Android Studio에서 이 폴더(Open) 선택
2. Gradle Sync 완료 (JDK 17+, Android SDK 35 설치)
3. 메뉴 Build > Build Bundle(s) / APK(s) > Build APK(s)
4. app/build/outputs/apk/debug/app-debug.apk 생성
5. APK를 Android 기기에 복사해 설치

GitHub 자동 APK 빌드: 이 프로젝트를 GitHub 저장소 루트에 올리면 Actions에서 수동 실행하거나 main 브랜치에 푸시할 때 Build NULL LUCK MAN APK가 실행되도록 workflow가 포함돼 있습니다. 빌드된 APK는 Actions Artifacts에서 받을 수 있습니다. GitHub 연결과 저장소 등록은 별도 단계입니다.

- 게임 화면: 가로 모드 고정
- 주 대상: Galaxy Z Fold8 외부 화면 1972 x 1248 가로
- 오프라인: 게임 assets/index.html 단일 내장 HTML 사용
- 세이브: Android WebView 앱 내부 LocalStorage (브라우저의 기존 저장과 자동 동기화되지 않음)
- 기존 브라우저 세이브는 JSON 백업/불러오기 기능을 이용해 이전할 수 있습니다.
- Android Studio가 설치된 PC가 아니면 별도 컴파일이 필요합니다.
